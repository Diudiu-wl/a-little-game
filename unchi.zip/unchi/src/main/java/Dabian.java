package main.java;

import javax.swing.*;
import java.awt.*;

public class Dabian extends Figure{

    public Dabian(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }
}
