package main.java;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Level3 extends JFrame {
    private int WIDTH = 1200;
    private int HEIGHT = 800;
    private int size = 140;
    private int y = 480;
    private Image image = new ImageIcon(Level3.class.getResource("resources/liwu.png")).getImage();
    private Image image1 = new ImageIcon(Level3.class.getResource("resources/jiang.png")).getImage();
    private Image image2 = new ImageIcon(Level3.class.getResource("resources/zi.png")).getImage();

    private Wo wo1 = new Wo(250, y, size, size, image);
    private Wo wo2 = new Wo(475, y, size, size, image);
    private Wo wo3 = new Wo(700, y, size, size, image);
    private Wo jiang = new Wo(300, 0, 420, 300, image1);
    private Wo zi = new Wo(290, 230, 400, 200, image2);

    public Level3() {
        this.setTitle("兑奖处");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(WIDTH, HEIGHT);

        Pane3 pane = new Pane3(wo1, wo2, wo3, jiang, zi);
        this.add(pane);
        this.setVisible(true);

        pane.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                if(touch(x, y, wo1)) {
                    JOptionPane.showMessageDialog(null, "恭喜获得：\n小零食一个！\n奖品编号:384");
                }
                else if(touch(x, y, wo2)) {
                    JOptionPane.showMessageDialog(null, "恭喜获得：\n游戏周边头像+壁纸!\n(随机)\n奖品编号:249");
                }
                else if(touch(x, y, wo3)) {
                    JOptionPane.showMessageDialog(null, "恭喜获得：\n游戏周边小本子一本!\n奖品编号:195");
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    private void close() {
        this.dispose();
    }
    private boolean touch(int x, int y, Figure f) {
        return x <= f.getX() + f.getWidth() && x >= f.getX()
                && y <= f.getY() + f.getHeight() && y >= f.getY();
    }

}
