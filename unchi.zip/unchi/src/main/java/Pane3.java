package main.java;

import javax.swing.*;
import java.awt.*;

public class Pane3 extends JPanel {
    private Wo[] wos;

    public Pane3(Wo... wos) {
        this.wos = wos;
    }
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        for(Wo wo : wos) {
            g.drawImage(wo.getImage(), wo.getX(), wo.getY(), wo.getWidth(), wo.getHeight(), this);
        }
    }
}
