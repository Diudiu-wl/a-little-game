package main.java;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;

public class Pane1 extends JPanel {
    private Cesuo cesuo;
    private Tiantong tiantong;
    private Wenzi wenzi;
    private Dabian dabian;
    private Duihua duihua;

    public Pane1(Cesuo cesuo, Tiantong tiantong, Wenzi wenzi, Dabian dabian, Duihua duihua) {
        this.cesuo = cesuo;
        this.tiantong = tiantong;
        this.wenzi = wenzi;
        this.dabian = dabian;
        this.duihua = duihua;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.drawImage(cesuo.getImage(), cesuo.getX(), cesuo.getY(), cesuo.getWidth(), cesuo.getHeight(), null);
        g.drawImage(tiantong.getImage(), tiantong.getX(), tiantong.getY(), tiantong.getWidth(), tiantong.getHeight(), null);
        g.drawImage(wenzi.getImage(), wenzi.getX(), wenzi.getY(), wenzi.getWidth(), wenzi.getHeight(), null);
        g.drawImage(dabian.getImage(), dabian.getX(), dabian.getY(), dabian.getWidth(), dabian.getHeight(), null);
        g.drawImage(duihua.getImage(), duihua.getX(), duihua.getY(), duihua.getWidth(), duihua.getHeight(), null);
    }

}
