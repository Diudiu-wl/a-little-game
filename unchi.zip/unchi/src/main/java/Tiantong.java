package main.java;

import javax.swing.*;
import java.awt.*;

public class Tiantong extends Figure{

    public Tiantong(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }
}
