package main.java;

import java.awt.*;

public class Wo extends Figure{
    public Wo(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }
}
