package main.java;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class Game extends JFrame {
    private final Image cesuoImage = new ImageIcon(Game.class.getResource("resources/matong.png")).getImage();
    //private final Image cesuoImage = new ImageIcon("src/main/resources/matong.png").getImage();
    private final Image tiantongImage = new ImageIcon(Game.class.getResource("resources/tiantong.png")).getImage();
    private final Image wenziImage = new ImageIcon(Game.class.getResource("resources/jia.png")).getImage();
    private final Image dabianImage = new ImageIcon(Game.class.getResource("resources/shi.png")).getImage();
    private final Image duihuaImage = new ImageIcon(Game.class.getResource("resources/duihua.png")).getImage();

    private final Tiantong tiantong = new Tiantong(200, 430, 140, 100, tiantongImage);
    private final Wenzi wenzi = new Wenzi(811, 130, 30, 30, null); //jia.png
    private final Cesuo cesuo = new Cesuo(800, 355, 250, 250, cesuoImage);
    private final Dabian dabian = new Dabian(520, 100, 150, 210, dabianImage);

    private Rectangle tiantongRec = new Rectangle(tiantong.getX(), tiantong.getY(), tiantong.getWidth(), tiantong.getHeight());
    private Rectangle cesuoRec = new Rectangle(cesuo.getX(), cesuo.getY(), cesuo.getWidth(), cesuo.getHeight());
    private Rectangle wenziRec = new Rectangle(wenzi.getX(), wenzi.getY(), wenzi.getWidth(), wenzi.getHeight());

    private boolean operation = true;

    public boolean isOperation() {
        return operation;
    }

    public Game() {
        this.setTitle("解谜小游戏");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1200, 800);
        //this.getContentPane().setBackground(Color.red);

        Duihua duihua = new Duihua(650, 40, 320, 180, duihuaImage);

        Pane1 plane = new Pane1(cesuo, tiantong, wenzi, dabian, duihua);
        this.add(plane);

        this.setVisible(true);

        plane.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                if(touch(x, y, dabian)) {
                    dabian.setImage(new ImageIcon(Game.class.getResource("resources/bian.png")).getImage());
                    dabian.setWidth(210);
                    dabian.setHeight(150);
                    dabian.setX(x - dabian.getWidth()/2);
                    dabian.setY(y - dabian.getHeight()/2);
                    plane.repaint();
                }

                Rectangle dabianRec = new Rectangle(dabian.getX(), dabian.getY(), dabian.getWidth(),dabian.getHeight());

                if(dabianRec.intersects(tiantongRec)) {
                    tiantong.setImage(new ImageIcon(Game.class.getResource("resources/tiantong2.png")).getImage());
                    tiantong.setWidth(165);
                    tiantong.setHeight(115);
                    tiantong.setX(200);
                    tiantong.setY(430);
                    plane.repaint();
                }
                else {
                    tiantong.setImage(tiantongImage);
                    tiantong.setWidth(140);
                    tiantong.setHeight(100);
                    tiantong.setX(200);
                    tiantong.setY(430);
                    plane.repaint();
                }

                if(dabianRec.intersects(cesuoRec)) {
                    cesuo.setImage(new ImageIcon(Game.class.getResource("resources/matong2.png")).getImage());
                    cesuo.setWidth(280);
                    cesuo.setHeight(280);
                    cesuo.setY(345);
                    plane.repaint();
                }
                else {
                    cesuo.setImage(cesuoImage);
                    cesuo.setWidth(250);
                    cesuo.setHeight(250);
                    cesuo.setY(355);
                    plane.repaint();
                }

            }

            @Override
            public void mouseMoved(MouseEvent e) {
                /*
                int x = e.getX();
                int y = e.getY();

                if(touch(x, y, cesuo)) {
                    cesuo.setImage(new ImageIcon("src/main/resources/matong2.png").getImage());
                    cesuo.setWidth(190);
                    cesuo.setHeight(190);
                    plane.repaint();
                }
                else {
                    cesuo.setImage(cesuoImage);
                    cesuo.setWidth(160);
                    cesuo.setHeight(160);
                    plane.repaint();
                }


                if(touch(x, y, tiantong)) {
                    tiantong.setImage(new ImageIcon("src/main/resources/tiantong2.png").getImage());
                    tiantong.setWidth(165);
                    tiantong.setHeight(115);
                    plane.repaint();
                }
                else {
                    tiantong.setImage(tiantongImage);
                    tiantong.setWidth(140);
                    tiantong.setHeight(100);
                    plane.repaint();
                }

                 */
            }
        });

        plane.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}

            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                if(touch(x, y, dabian)) {
                    dabian.setImage(new ImageIcon(Game.class.getResource("resources/bian.png")).getImage());
                    dabian.setWidth(210);
                    dabian.setHeight(150);
                    dabian.setX(x - dabian.getWidth()/2);
                    dabian.setY(y - dabian.getHeight()/2);
                    plane.repaint();
                }
                /*
                int x = e.getX();
                int y = e.getY();
                if(touch(x, y, cesuo)){
                    cesuo.setImage(new ImageIcon("src/main/resources/diao.png").getImage());
                    cesuo.setWidth(200);
                    cesuo.setHeight(200);
                    plane.repaint();
                    JOptionPane.showMessageDialog(null, "可惜不是这里");
                }

                else if(touch(x, y, tiantong)) {
                    tiantong.setImage(new ImageIcon("src/main/resources/icecr.png").getImage());
                    tiantong.setWidth(210);
                    tiantong.setHeight(150);
                    tiantong.setY(500);
                    plane.repaint();
                    tiantong.setY(530);
                    JOptionPane.showMessageDialog(null, "可惜不是这里");
                }

                else if(touch(x, y, wenzi)) {
                    JOptionPane.showMessageDialog(null, "谢谢你，好心人");
                    JOptionPane.showMessageDialog(null, "恭喜通关！");
                }

                 */
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                Rectangle dabianRec = new Rectangle(dabian.getX(), dabian.getY(), dabian.getWidth(), dabian.getHeight());
                if(dabianRec.intersects(tiantongRec)) {
                    dabian.setImage(null);
                    tiantong.setImage(new ImageIcon(Game.class.getResource("resources/icecr.png")).getImage());
                    tiantong.setWidth(280);
                    tiantong.setHeight(200);
                    tiantong.setX(170);
                    tiantong.setY(345);
                    plane.repaint();
                    JOptionPane.showMessageDialog(null, "我看着那么好吃吗（坏笑）");
                    JOptionPane.showMessageDialog(null, "可惜不是这里，请把我拖出来。");
                    return;
                }
                else if(dabianRec.intersects(cesuoRec)) {
                    dabian.setImage(null);
                    cesuo.setImage(new ImageIcon(Game.class.getResource("resources/diao.png")).getImage());
                    cesuo.setWidth(290);
                    cesuo.setHeight(290);
                    cesuo.setY(330);
                    plane.repaint();
                    //cesuo.setY(500);
                    JOptionPane.showMessageDialog(null, "呜呜，好过分。");
                    JOptionPane.showMessageDialog(null, "可惜不是这里，请把我拖出来。");
                    return;
                }
                else if(dabianRec.intersects(wenziRec)) {
                    dabian.setImage(null);
                    plane.repaint();
                    JOptionPane.showMessageDialog(null, "谢谢你，好心人。");
                    JOptionPane.showMessageDialog(null, "恭喜通关！");
                    String[] options = {"好耶", "好耶"};
                    int choice = JOptionPane.showOptionDialog(null, "要进入下一关吗?",null, JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
                    if(choice == 0 || choice == 1) {
                        //进入第二关
                        close();
                        new Level2();
                    }
                }
                else {
                    dabian.setImage(dabianImage);
                    dabian.setWidth(150);
                    dabian.setHeight(210);
                    plane.repaint();
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {}

            @Override
            public void mouseExited(MouseEvent e) {}

        });

    }
    private boolean touch(int x, int y, Figure f) {
        return x <= f.getX() + f.getWidth() && x >= f.getX()
                && y <= f.getY() + f.getHeight() && y >= f.getY();
    }

    public void close() {
        this.dispose();
    }


    public static void main(String[] args) {
        new Game();
    }

}
