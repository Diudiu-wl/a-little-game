package main.java;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class                                                                                                                                                                                                                                                                                                  Level2 extends JFrame {
    private final int WIDTH = 1200;
    private final int HEIGHT = 800;
    private final int width = 65;
    private final int height = 52;
    private final int new_width = width + 5;
    private final int new_height = height + 5;

    private final int begin_x = 270;
    private final int begin_y = 200;
    private final int distance = 160;
    private final int ANSWER_X = 45;
    private final int ANSWER_Y = 128;
    private final int ANSWER_WIDTH = 56;
    private final int ANSWER_HEIGHT = 40;

    private Image image1 = new ImageIcon(Level2.class.getResource("resources/wo.png")).getImage();
    private Image image2 = new ImageIcon(Level2.class.getResource("resources/wo5.png")).getImage();
    private Image duihuaImage = new ImageIcon(Level2.class.getResource("resources/kuang.png")).getImage();
    private Image woImage = new ImageIcon(Level2.class.getResource("resources/answer.png")).getImage();
    private Image juhaoImage = new ImageIcon(Level2.class.getResource("resources/juhao.png")).getImage();
    private Image fen = new ImageIcon(Level2.class.getResource("resources/fen.png")).getImage();
    private Image cai = new ImageIcon(Level2.class.getResource("resources/cai.png")).getImage();
    private Image jin = new ImageIcon(Level2.class.getResource("resources/jin.png")).getImage();
    private Image zong = new ImageIcon(Level2.class.getResource("resources/zong.png")).getImage();
    private Image lv = new ImageIcon(Level2.class.getResource("resources/lv.png")).getImage();
    private Image caihong = new ImageIcon(Level2.class.getResource("resources/caihong.png")).getImage();

    boolean jinPressed = false;
    boolean zongPressed = false;
    boolean caiPressed = false;


    /*
    private Wo wo1 = new Wo(begin_x, begin_y, width, height, image1);
    private Wo wo2 = new Wo(begin_x + distance, begin_y, width, height, image1);
    private Wo wo3 = new Wo(begin_x + 2 * distance, begin_y, width, height, image1);
    private Wo wo4 = new Wo(begin_x, begin_y + distance, width, height, image1);
    private Wo wo5 = new Wo(begin_x + distance, begin_y + distance, width, height, image2);
    private Wo wo6 = new Wo(begin_x + 2 * distance, begin_y + distance, width, height, image1);
    private Wo wo7 = new Wo(begin_x, begin_y + 2 * distance, width, height, image1);
    private Wo wo8 = new Wo(begin_x + distance, begin_y + 2 * distance, width, height, image1);

     */

    private final Wo[] woss = new Wo[9];
    //private final int[] wo_x = new int[9];
    //private final int[] wo_y = new int[9];

    private Wo duihua = new Wo(105, -105, 640, 360, duihuaImage);
    private Wo juhao = new Wo(667, 117, 29, 29, null);
    private Wo answer = new Wo(ANSWER_X, ANSWER_Y, ANSWER_WIDTH, ANSWER_HEIGHT, null);

    private boolean enable = false;
    private boolean pressable = false;
    //private boolean[] pressable = {false, false, false, false, false, false};
    private int pressCount = 0;
    private int[] index = {0, 0, 0, 0, 0};
    private boolean win = false;

    public Level2() {

        int count = 0;
        for(int i = 0; i < 3; i ++) {
            for(int j = 0; j < 3; j++) {
                if(i == 1 && j == 1) {
                    woss[count] = new Wo(begin_x + j * distance, begin_y + i * distance, width, height, jin);
                }
                else if(i == 2 && j == 0) {
                    woss[count] = new Wo(begin_x + j * distance, begin_y + i * distance, width, height, zong);
                }
                else if(i == 2 && j == 2) {
                    woss[count] = new Wo(begin_x + j * distance, begin_y + i * distance, width, height, cai);
                }
                else {
                    woss[count] = new Wo(begin_x + j * distance, begin_y + i * distance, width, height, image1);
                }
                //wo_x[count] = begin_x + j * distance;
                //wo_y[count] = begin_y + i * distance;
                count ++;
            }
        }

        this.setTitle("第二关");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(WIDTH, HEIGHT);
        this.setLayout(null);

        Pane2 pane = new Pane2(woss, duihua, juhao, answer);
        pane.setBounds(0,0, 750, HEIGHT);
        this.add(pane);
        JButton duijiang = new JButton("兑奖");
        duijiang.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String response = JOptionPane.showInputDialog("请输入兑奖码(仅数字)：");
                if(response == null) {
                    return;
                }
                if(response.equals("001137")) {
                    close();
                    new Level3();
                }
                else {
                    JOptionPane.showMessageDialog(null, "兑奖码错误。");
                }
            }
        });
        duijiang.setBounds(800, 120, 80, 50);

        this.add(duijiang);

        this.setVisible(true);

        pane.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                for(Wo wo : woss) {
                    if(touch(x, y, wo)) {
                        if((wo == woss[4] && jinPressed) || wo == woss[6] && zongPressed || wo == woss[8] && caiPressed) {
                            wo.setWidth(new_width + 5);
                            wo.setHeight(new_height + 5);
                        }
                        else {
                            wo.setWidth(width + 5);
                            wo.setHeight(height + 4);
                        }
                        pane.repaint();
                    }
                    else {
                        if((wo == woss[4] && jinPressed) || wo == woss[6] && zongPressed || wo == woss[8] && caiPressed) {
                            wo.setWidth(new_width);
                            wo.setHeight(new_height);
                        }
                        else {
                            wo.setWidth(width);
                            wo.setHeight(height);
                        }
                        pane.repaint();
                    }
                }
            }
        });

        pane.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                for(Wo wo : woss) {
                    if(touch(x, y, wo)) {
                        if(!jinPressed && wo == woss[4]) {
                            wo.setImage(lv);
                            jinPressed = true;
                        }
                        else if(!zongPressed && wo == woss[6]) {
                            wo.setImage(fen);
                            zongPressed = true;
                        }
                        else if(!caiPressed && wo == woss[8]) {
                            wo.setImage(caihong);
                            caiPressed = true;
                        }
                        else if((wo == woss[4] && jinPressed) || wo == woss[6] && zongPressed || wo == woss[8] && caiPressed) {
                            wo.setWidth(new_width);
                            wo.setHeight(new_height);
                        }
                        else {
                            wo.setWidth(width);
                            wo.setHeight(height);
                        }
                        pane.repaint();

                        //if(win) return;

                        if(pressable) {
                            pressCount ++;
                            //正确输入时
                            if(wo == woss[1]) index[pressCount - 1] = 2;
                            if(wo == woss[2]) index[pressCount - 1] = 3;
                            if(wo == woss[0]) index[pressCount - 1] = 1;
                            if(wo == woss[8]) index[pressCount - 1] = 9;
                            if(wo == woss[6]) index[pressCount - 1] = 7;

                            if(pressCount == 5) {
                                if(index[0] != 2 || index[1] != 3 || index[2] != 1 || index[3] != 9 || index[4] != 7) {
                                    tryAgain();
                                }
                                else {
                                    pressCount = 0;
                                    JButton ok = new JButton("ok");
                                    ok.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            JOptionPane.getRootFrame().setVisible(false);
                                        }
                                    });
                                    JPanel panel1 = new JPanel();
                                    ok.setPreferredSize(new Dimension(60, 30));
                                    panel1.add(ok);

                                    win = true;
                                    JOptionPane.showOptionDialog(null, "恭喜通过隐藏关！\n你可以去兑换奖品啦~\n奖品兑换码：001137", "提示",
                                            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{panel1}, null);

                                }

                            }
                        }

                        else normalAlert();
                    }
                }
                if(touch(x, y, juhao)) {
                    answer.setImage(woImage);
                    enable = true;
                    pane.repaint();
                    normalAlert();
                }

                if(enable && touch(x, y, answer)) {
                    alert();
                    //close();
                }

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    private void tryAgain() {
        JButton again = new JButton("重新输一次");
        again.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.getRootFrame().setVisible(false);
                pressCount = 0;
            }
        });
        JPanel panel1 = new JPanel();
        again.setPreferredSize(new Dimension(150, 30));
        panel1.add(again);

        JOptionPane.showOptionDialog(null, "通关码错误。", "提示",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{panel1}, null);
    }

    private void normalAlert() {

        ImageIcon icon = new ImageIcon(Level2.class.getResource("resources/xinlian1.png"));
        Image img = icon.getImage();
        Image newimg = img.getScaledInstance(120, 120, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newimg);

        JLabel label = new JLabel(icon);
        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {}
        });
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(label, BorderLayout.CENTER);

        JButton ok = new JButton("ok");
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.getRootFrame().setVisible(false);
            }
        });
        JPanel panel1 = new JPanel();
        ok.setPreferredSize(new Dimension(60, 30));
        panel1.add(ok);

        /*
        JButton button = new JButton("·_·");
        button.setOpaque(false);

        Object[] options = {ok, "·_·"};
        JOptionPane.showOptionDialog(null, "错啦。", "提示",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{button, ok}, button);

         */


        JOptionPane.showOptionDialog(null, "错啦。", "提示",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{panel, panel1}, null);

    }
    private void alert() {
        ImageIcon icon = new ImageIcon(Level2.class.getResource("resources/xinlian2.png"));
        Image img = icon.getImage();
        Image newimg = img.getScaledInstance(120, 120, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newimg);
        /*
        JButton button = new JButton(icon);
        button.setPreferredSize(new Dimension(70,50));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "恭喜");
            }
        });
        JButton ok = new JButton("ok");
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.getRootFrame().setVisible(false);
            }
        });
        JOptionPane.showOptionDialog(null, "lalala", "blabla",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{button, ok}, null);

         */
        JButton ok = new JButton("ok");
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.getRootFrame().setVisible(false);
            }
        });
        JPanel panel1 = new JPanel();
        ok.setPreferredSize(new Dimension(60, 30));
        panel1.add(ok);

        JLabel label = new JLabel(icon);

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //JOptionPane.showMessageDialog(null, "恭喜通关！");
                String[] options = {"不要", "不要"};
                int result = JOptionPane.showOptionDialog(null, "恭喜通关！", "提示",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{ok}, null);
                int choice = JOptionPane.showOptionDialog(null, "想要隐藏关需要的码吗？", "提示",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
                if(result == 0) {
                    JOptionPane.getRootFrame().setVisible(false);
                }
                if(choice == 0 || choice == 1) {
                    JOptionPane.getRootFrame().setVisible(false);
                }
                else {
                    int newResult = JOptionPane.showOptionDialog(null, "欢迎来到隐藏关！\n隐藏关码：23197", "提示",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{ok}, null);
                    if(newResult == 0) {
                        JOptionPane.getRootFrame().setVisible(false);
                    }
                    pressable = true;
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(label, BorderLayout.CENTER);

        JOptionPane.showOptionDialog(null, "错啦。", "提示",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{panel, panel1}, null);

    }
    private void close() {
        this.dispose();
    }
    private boolean touch(int x, int y, Figure f) {
        return x <= f.getX() + f.getWidth() && x >= f.getX()
                && y <= f.getY() + f.getHeight() && y >= f.getY();
    }

    /*
    public static void main(String[] args) {
        new Level2();
    }

     */



}
