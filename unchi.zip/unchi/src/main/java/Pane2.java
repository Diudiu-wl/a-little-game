package main.java;

import javax.swing.*;
import java.awt.*;

public class Pane2 extends JPanel {
    private Wo[] wos;
    private Wo[] rest;

    public Pane2(Wo[] wos, Wo... rest) {
        this.wos = wos;
        this.rest = rest;
    }
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        for(Wo wo : wos) {
            g.drawImage(wo.getImage(), wo.getX(), wo.getY(), wo.getWidth(), wo.getHeight(), this);
        }
        for(Wo wo : rest) {
            g.drawImage(wo.getImage(), wo.getX(), wo.getY(), wo.getWidth(), wo.getHeight(), this);
        }

    }
}
